var searchData=
[
  ['nb_5fskiers',['NB_SKIERS',['../main_8cpp.html#ab6263e6358f224358ec3caf22edec500',1,'main.cpp']]],
  ['nbskiersinside',['nbSkiersInside',['../class_pco_cable_car.html#aa3f6dcd464d40c74db2f72d14d979f81',1,'PcoCableCar']]],
  ['nbskierswaiting',['nbSkiersWaiting',['../class_pco_cable_car.html#a2e717191fc2b7b82ed78b2bfef8f8b49',1,'PcoCableCar']]],
  ['nextid',['nextId',['../class_skier_behavior.html#acdba418cb2f03df82cf435da843356ba',1,'SkierBehavior']]]
];
