#include "criticalsection.h"
#include <vector>
#include <algorithm>
#include <thread>
#include <atomic>

std::vector<int> tickets;
std::vector<int> entering;

void WonderfulCriticalSection::initialize(unsigned int nbThreads)
{
    tickets.resize(nbThreads);
    entering.resize(nbThreads);

    /* Set default values in the vectors */
    for(unsigned int i = 0; i < nbThreads; i++){
        tickets.push_back(0);
        entering.push_back(false);
    }
}

void WonderfulCriticalSection::lock(unsigned int index)
{
    entering.at(index) = true;

    int max = 0;

    for(int ticket: tickets) {
        max = std::max(max, ticket);
    }

    tickets.at(index) = max + 1;
    entering.at(index) = false;

    for(unsigned int i = 0; i < tickets.size(); i++){
        if(i != index){
            while(entering.at(i)){ std::this_thread::yield(); }
            while(tickets.at(i) != 0 && (tickets.at(index) > tickets.at(i) || (tickets.at(index) == tickets.at(i) && index > i)))
            { std::this_thread::yield(); }
        }
    }
}

void WonderfulCriticalSection::unlock(unsigned int index)
{
    tickets.at(index) = 0;
}
